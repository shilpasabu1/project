import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user:any;
  collapse:boolean=true;
  constructor() {this.user={name:'noora',
  job:'softaware developer',
  addrs:'1234 kottayam,city,state,1234',
  
    phone:
    ['123-123-123',
    '774-784-75']
};
}

toggle()
{
 this. collapse=!this.collapse;
}
  ngOnInit() 
  {
  }

}
