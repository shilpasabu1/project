import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hai',
  templateUrl: './hai.component.html',
  styleUrls: ['./hai.component.css']
})
export class HaiComponent implements OnInit {
message:string=new Date().toDateString();
anynumber:number=10;
  constructor() { }

  ngOnInit() {
  }
  addtwonumber(a:number,b:number)
  {
    return a+b;
  }

}
