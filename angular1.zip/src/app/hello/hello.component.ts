
import { Component,OnInit } from '@angular/core';
import {NgForm} from '@angular/forms'
import { HttpClient } from '@angular/common/http';
import { student } from '../student';
import { StoreService } from '../store.service';

@Component({
  selector: 'app-hello',
  templateUrl: './hello.component.html',
  styleUrls: ['./hello.component.css']
})
export class HelloComponent implements OnInit 
{
  student=new student();
 error='';
 success='';

  constructor(private storeservice: StoreService) 
  {
    
 
   }

  ngOnInit() 
  {
  }
  registration(f: NgForm)
  {
this.storeservice.store(this.student).subscribe(data=>{this.success="sucesssfully inserted"; f.resetForm()},
  
(err)=>{this.error="error occured";});
  

}
}
