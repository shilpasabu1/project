export class student
{
    name:string;
    password:string;
    email:string;
    id?:number;
    constructor()
    {
        
    }
}